-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2020 at 06:17 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mynewdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `formdata`
--

CREATE TABLE `formdata` (
  `site` text NOT NULL,
  `streetadd` varchar(200) NOT NULL,
  `telephone` int(50) NOT NULL,
  `city` text NOT NULL,
  `officeemail` varchar(50) NOT NULL,
  `state` text NOT NULL,
  `website` text NOT NULL,
  `pincode` int(10) NOT NULL,
  `eavailable` varchar(10) NOT NULL,
  `ename` text NOT NULL,
  `estreet` varchar(100) NOT NULL,
  `etelephone` int(50) NOT NULL,
  `ecity` text NOT NULL,
  `eofficeemail` varchar(50) NOT NULL,
  `estate` text NOT NULL,
  `ewebsite` text NOT NULL,
  `epincode` int(50) NOT NULL,
  `registered` varchar(10) NOT NULL,
  `ecno` varchar(50) NOT NULL,
  `certificate` varchar(100) NOT NULL,
  `finalname` varchar(100) NOT NULL,
  `designation` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `formdata`
--

INSERT INTO `formdata` (`site`, `streetadd`, `telephone`, `city`, `officeemail`, `state`, `website`, `pincode`, `eavailable`, `ename`, `estreet`, `etelephone`, `ecity`, `eofficeemail`, `estate`, `ewebsite`, `epincode`, `registered`, `ecno`, `certificate`, `finalname`, `designation`) VALUES
('mysite', 'at post manmad', 9028, 'mumbai', 'prasad', 'maharashtra', 'wwwgoogle', 999, 'yes', 'prasad', 'at post manmad', 999222, 'mumbai', 'officeemailnew', 'maharashtra', 'ppprrrvvv', 1010, 'yes', '12313', '', 'prasad', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'prasadvaskar', 'vaskar'),
(2, 'mohit', 'mohit');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
